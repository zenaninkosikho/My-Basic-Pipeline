// client/src/components/EmployeeLogin.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function EmployeeLogin() {
  const [formData, setFormData] = useState({
    accountNumber: '',
    password: ''
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://localhost:3000/employeelogin', formData);
      setMessage(response.data.message);

      // Save JWT token to localStorage
      localStorage.setItem('employeeToken', response.data.token);

      // Redirect to the employee dashboard or the transactions page
      navigate('/employeedashboard');
    } catch (error) {
      setMessage(error.response?.data.error || 'Login failed');
    }
  };

  return (
    <div>
      <h2>Employee Login</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Account Number:
          <input type="text" name="accountNumber" value={formData.accountNumber} onChange={handleChange} required />
        </label>
        <br />
        <label>
          Password:
          <input type="password" name="password" value={formData.password} onChange={handleChange} required />
        </label>
        <br />
        <button type="submit">Log In</button>
      </form>
      {message && <p>{message}</p>}
      
      <button onClick={() => navigate('/login')}>Login as Customer</button>
    </div>
  );
}

export default EmployeeLogin;
