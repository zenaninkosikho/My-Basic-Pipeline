// client/src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login() {
  const [formData, setFormData] = useState({
    accountNumber: '',
    password: ''
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://localhost:3000/login', formData);
      setMessage(response.data.message);

      // Save JWT token to local storage or state for session management
      localStorage.setItem('token', response.data.token);

      // Redirect to the Payment page upon successful login
      navigate('/payment');
    } catch (error) {
      setMessage(error.response?.data.error || 'Login failed');
    }
  };

  return (
    <div className="login-container">
      <h2>Customer Login</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Account Number:
          <input type="text" name="accountNumber" value={formData.accountNumber} onChange={handleChange} required />
        </label>
        <br />
        <label>
          Password:
          <input type="password" name="password" value={formData.password} onChange={handleChange} required />
        </label>
        <br />
        <button type="submit">Log In</button>
      </form>
      {message && <p>{message}</p>}
      
      <button onClick={() => navigate('/register')}>Register</button>
      <br></br>
      <button onClick={() => navigate('/employeelogin')}>Log In as Employee</button>
    </div>
  );
}

export default Login;
