// client/src/components/Payment.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Use useNavigate instead of useHistory

function Payment() {
  const [paymentData, setPaymentData] = useState({
    amount: '',
    currency: '',
    provider: '',
    recipientAccount: '',
    swiftCode: '',
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // Hook for navigation
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if the token exists in localStorage
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true); // User is logged in if token is present
    } else {
      setIsLoggedIn(false); // Redirect to login page if no token
      navigate('/login'); // Redirect user to login page if not logged in
    }
  }, [navigate]); // Trigger re-check whenever navigate changes

  const handleChange = (e) => {
    setPaymentData({
      ...paymentData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://localhost:3000/payment', paymentData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`, // Send token for auth
        },
      });
      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response?.data.error || 'Payment failed');
    }
  };

  const handleLogout = () => {
    // Remove token from local storage
    localStorage.removeItem('token');
    // Redirect to the login page
    navigate('/login'); // Use navigate to go to login page
  };

  return (
    <div>
      <h2>Make a Payment</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Amount:
          <input
            type="text"
            name="amount"
            value={paymentData.amount}
            onChange={handleChange}
            required
          />
        </label>
        <br />
        <label>
          Currency:
          <input
            type="text"
            name="currency"
            value={paymentData.currency}
            onChange={handleChange}
            required
          />
        </label>
        <br />
        <label>
          Provider:
          <input
            type="text"
            name="provider"
            value={paymentData.provider}
            onChange={handleChange}
            required
          />
        </label>
        <br />
        <label>
          Recipient Account:
          <input
            type="text"
            name="recipientAccount"
            value={paymentData.recipientAccount}
            onChange={handleChange}
            required
          />
        </label>
        <br />
        <label>
          SWIFT Code:
          <input
            type="text"
            name="swiftCode"
            value={paymentData.swiftCode}
            onChange={handleChange}
            required
          />
        </label>
        <br />
        <button type="submit">Pay Now</button>
      </form>
      {message && <p>{message}</p>}
      {/* Render Logout button only if user is logged in */}
      {isLoggedIn && <button onClick={handleLogout}>Logout</button>}
    </div>
  );
}

export default Payment;
