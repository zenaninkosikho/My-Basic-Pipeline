import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './EmployeeDashboard.css';

function EmployeeDashboard() {
  const [payments, setPayments] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch payments from backend
    axios.get('https://localhost:3000/payments', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('employeeToken')}`,
      },
    })
    .then((response) => {
      setPayments(response.data);
    })
    .catch((error) => {
      console.error('Error fetching payments:', error);
    });
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('employeeToken');
    navigate('/employeelogin');
  };

  const handleVerify = (paymentId, customerId) => {
    // Send request to verify the payment and move it to the transactions collection
    axios.post('https://localhost:3000/paymentverify', { paymentId, customerId }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('employeeToken')}`,
      },
    })
    .then((response) => {
      alert(response.data.message);
      // Update state to reflect the verified payment
      setPayments((prevPayments) =>
        prevPayments.filter((payment) => payment._id !== paymentId)
      );
    })
    .catch((error) => {
      console.error('Error verifying payment:', error);
      alert('Failed to verify payment');
    });
  };

  const handleSubmitToSWIFT = () => {
    // Submit all verified transactions to SWIFT
    axios.post('https://localhost:3000/submitAllToSWIFT', {}, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('employeeToken')}`,
      },
    })
    .then((response) => {
      console.log('All verified transactions submitted to SWIFT:', response.data);
      alert(response.data.message);
      // Optionally, clear the list of payments if necessary
      setPayments([]);
    })
    .catch((error) => {
      console.error('Error submitting to SWIFT:', error.response?.data || error.message);
      alert('Failed to submit transactions to SWIFT');
    });
  };

  return (
    <div>
      <h2>Employee Dashboard</h2>
      <button onClick={handleLogout}>Logout</button>
      <h3>Pending Payments</h3>
      {/* Render payments in a table */}
      <table>
        <thead>
          <tr>
            <th>Amount</th>
            <th>Currency</th>
            <th>Recipient Account</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((payment) => (
            <tr key={payment._id}>
              <td>{payment.amount}</td>
              <td>{payment.currency}</td>
              <td>{payment.recipientAccount}</td>
              <td>{payment.status}</td>
              <td>
                {/* Button to verify the payment */}
                <button onClick={() => handleVerify(payment._id, payment.customerId)}>
                  Verify
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Submit All Verified Transactions to SWIFT</h3>
      <button onClick={handleSubmitToSWIFT}>Submit to SWIFT</button>
    </div>
  );
}

export default EmployeeDashboard;
