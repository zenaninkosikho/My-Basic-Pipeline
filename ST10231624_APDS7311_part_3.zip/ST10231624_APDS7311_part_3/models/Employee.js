// models/Employee.js

const mongoose = require('mongoose');

// Employee schema definition
const employeeSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
  },
  accountNumber: {
    type: String,
    unique: true,
    required: true,
  },
  passwordHash: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ['employee'],  // Since only employees can log in
    default: 'employee',
  },
}, { timestamps: true });

// Create a model from the schema
const Employee = mongoose.model('Employee', employeeSchema);

module.exports = Employee;
