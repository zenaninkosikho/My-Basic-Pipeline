const mongoose = require('mongoose');

const swiftSchema = new mongoose.Schema({
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },

  amount: { type: Number, required: true },
  currency: { type: String, required: true },
  provider: { type: String, required: true },
  recipientAccount: { type: String, required: true },
  swiftCode: { type: String, required: true },
  status: { type: String, default: 'submitted' },
  createdAt: { type: Date, default: Date.now },
});

const Swift = mongoose.model('Swift', swiftSchema);

module.exports = Swift;
