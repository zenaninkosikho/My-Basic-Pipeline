// models/Payment.js
const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema(
  {
    amount: {
      type: String,
      required: true,
    },
    currency: {
      type: String,
      required: true,
    },
    provider: {
      type: String,
      required: true,
    },
    recipientAccount: {
      type: String,
      required: true,
    },
    swiftCode: {
      type: String,
      required: true,
    },
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer', // Reference to the Customer model
      required: true,
    },
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt fields
  }
);

const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
